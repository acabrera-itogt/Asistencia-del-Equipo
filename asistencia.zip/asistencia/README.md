# Asistencia del equipo

Calendario compartido: oficina, remoto, comunidad/actividad y día libre, con registro de entrada/salida y exportación a CSV.
Stack: Node.js + Express + SQLite (un solo archivo de base de datos). Cada usuario solo edita sus propios registros.

## Ejecutar localmente
    npm install
    export JWT_SECRET="una-cadena-larga-y-aleatoria"
    export INVITE_CODE="codigo-para-tus-empleados"
    npm start            # http://localhost:3000

Genera un secreto con: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

## Publicar en tu dominio (VPS Ubuntu)
1. Apunta el DNS (registro A) de tu dominio a la IP del servidor.
2. Instala Node 18+, sube esta carpeta y ejecuta `npm install --omit=dev`.
3. Mantén el servidor activo con pm2:

       npm i -g pm2
       JWT_SECRET=... INVITE_CODE=... NODE_ENV=production pm2 start server.js --name asistencia
       pm2 save && pm2 startup

4. Nginx como proxy inverso (`/etc/nginx/sites-available/asistencia`):

       server {
         server_name asistencia.tudominio.com;
         location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_set_header Host $host;
           proxy_set_header X-Forwarded-For $remote_addr;
           proxy_set_header X-Forwarded-Proto $scheme;
         }
       }

5. HTTPS gratis: `sudo certbot --nginx -d asistencia.tudominio.com`

Con `NODE_ENV=production` la cookie de sesión exige HTTPS, así que activa el certificado antes de usarla.

## Notas
- Respaldo: copia el archivo `asistencia.db` (DB_PATH) periódicamente.
- Los datos se refrescan cada 8 segundos para todos los usuarios.
- Tras registrar a tu equipo, cambia o borra INVITE_CODE para cerrar los registros.
- Para PaaS (Render, Railway, Fly.io): comando de inicio `npm start`, variables de entorno anteriores y un volumen persistente para DB_PATH.
