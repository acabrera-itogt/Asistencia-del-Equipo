const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cookieParser = require('cookie-parser');
const path = require('path');

const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET;
const INVITE = process.env.INVITE_CODE || '';
const PROD = process.env.NODE_ENV === 'production';
if (!SECRET) { console.error('Falta la variable JWT_SECRET'); process.exit(1); }

const db = new Database(process.env.DB_PATH || 'asistencia.db');
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS entries(
  user_id INTEGER NOT NULL, date TEXT NOT NULL, status TEXT NOT NULL,
  t_in TEXT DEFAULT '', t_out TEXT DEFAULT '',
  PRIMARY KEY(user_id, date), FOREIGN KEY(user_id) REFERENCES users(id));
`);

const STATUS = ['office', 'remote', 'community', 'off'];
const LABEL = { office: 'Oficina', remote: 'Remoto', community: 'Comunidad/actividad', off: 'Día libre' };
const reDate = /^\d{4}-\d{2}-\d{2}$/, reTime = /^(\d{2}:\d{2})?$/;

const app = express();
app.set('trust proxy', 1);
app.use(express.json({ limit: '10kb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// Límite simple de intentos de login/registro (en memoria)
const tries = new Map();
const limited = (req, res, next) => {
  const k = req.ip, now = Date.now();
  const a = (tries.get(k) || []).filter(t => now - t < 15 * 60e3);
  if (a.length >= 15) return res.status(429).json({ error: 'Demasiados intentos. Espera unos minutos.' });
  a.push(now); tries.set(k, a); next();
};

const setSession = (res, u) => res.cookie('t', jwt.sign({ id: u.id, name: u.name }, SECRET, { expiresIn: '30d' }),
  { httpOnly: true, sameSite: 'lax', secure: PROD, maxAge: 30 * 864e5 });

const auth = (req, res, next) => {
  try { req.user = jwt.verify(req.cookies.t, SECRET); next(); }
  catch { res.status(401).json({ error: 'No autenticado' }); }
};

app.post('/api/register', limited, (req, res) => {
  const { name, username, password, invite } = req.body || {};
  if (INVITE && invite !== INVITE) return res.status(403).json({ error: 'Código de invitación incorrecto' });
  if (!name || !username || !password || password.length < 8)
    return res.status(400).json({ error: 'Completa todos los campos (contraseña de 8+ caracteres)' });
  try {
    const r = db.prepare('INSERT INTO users(username,name,hash) VALUES(?,?,?)')
      .run(String(username).trim().toLowerCase(), String(name).trim().slice(0, 60), bcrypt.hashSync(password, 10));
    const u = { id: r.lastInsertRowid, name: String(name).trim().slice(0, 60) };
    setSession(res, u); res.json(u);
  } catch { res.status(409).json({ error: 'Ese usuario ya existe' }); }
});

app.post('/api/login', limited, (req, res) => {
  const { username, password } = req.body || {};
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(String(username || '').trim().toLowerCase());
  if (!u || !bcrypt.compareSync(String(password || ''), u.hash)) return res.status(401).json({ error: 'Usuario o contraseña incorrectos' });
  setSession(res, u); res.json({ id: u.id, name: u.name });
});

app.post('/api/logout', (req, res) => { res.clearCookie('t'); res.json({ ok: true }); });
app.get('/api/me', auth, (req, res) => res.json({ id: req.user.id, name: req.user.name }));

app.get('/api/entries', auth, (req, res) => {
  const { from, to } = req.query;
  if (!reDate.test(from) || !reDate.test(to)) return res.status(400).json({ error: 'Rango inválido' });
  res.json(db.prepare(`SELECT e.date, e.status, e.t_in AS tin, e.t_out AS tout, u.id AS uid, u.name
    FROM entries e JOIN users u ON u.id=e.user_id WHERE e.date BETWEEN ? AND ? ORDER BY e.date, u.name`).all(from, to));
});

// Cada usuario solo puede escribir sus propios registros
app.put('/api/entries/:date', auth, (req, res) => {
  const { status, tin = '', tout = '' } = req.body || {};
  if (!reDate.test(req.params.date) || !STATUS.includes(status) || !reTime.test(tin) || !reTime.test(tout))
    return res.status(400).json({ error: 'Datos inválidos' });
  db.prepare(`INSERT INTO entries(user_id,date,status,t_in,t_out) VALUES(?,?,?,?,?)
    ON CONFLICT(user_id,date) DO UPDATE SET status=excluded.status,t_in=excluded.t_in,t_out=excluded.t_out`)
    .run(req.user.id, req.params.date, status, tin, tout);
  res.json({ ok: true });
});

app.get('/api/export', auth, (req, res) => {
  const m = String(req.query.month || '');
  if (!/^\d{4}-\d{2}$/.test(m)) return res.status(400).json({ error: 'Mes inválido (AAAA-MM)' });
  const safe = v => { v = String(v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
  const rows = db.prepare(`SELECT u.name, e.date, e.status, e.t_in, e.t_out FROM entries e
    JOIN users u ON u.id=e.user_id WHERE e.date LIKE ? ORDER BY e.date, u.name`).all(m + '-%');
  const csv = ['Persona,Fecha,Estado,Entrada,Salida']
    .concat(rows.map(r => [r.name, r.date, LABEL[r.status], r.t_in, r.t_out].map(safe).join(','))).join('\n');
  res.set({ 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="asistencia-${m}.csv"` });
  res.send('\ufeff' + csv);
});

app.listen(PORT, () => console.log('Asistencia en http://localhost:' + PORT));
